//
//  MeBleAppDelegate.h
//  MoosaTab
//
//  Created by sasiraj s on 19/9/12.
//  Copyright (c) 2012 appsmerry@gmail.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MeBleAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (nonatomic,retain) NSMutableArray *arrDevices;    //HarshIT

@end
