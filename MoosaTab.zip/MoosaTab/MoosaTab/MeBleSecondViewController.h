//
//  MeBleSecondViewController.h
//  MoosaTab
//
//  Created by sasiraj s on 19/9/12.
//  Copyright (c) 2012 appsmerry@gmail.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MeBleAppDelegate.h"

@interface MeBleSecondViewController : UIViewController
{
    MeBleAppDelegate *appDelegate;
}
@end
