//
//  main.m
//  MoosaTab
//
//  Created by sasiraj s on 19/9/12.
//  Copyright (c) 2012 appsmerry@gmail.com. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "MeBleAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([MeBleAppDelegate class]));
    }
}
