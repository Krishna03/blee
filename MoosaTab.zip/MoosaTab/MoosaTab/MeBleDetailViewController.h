//
//  MeBleDetailViewController.h
//  MoosaTab
//
//  Created by sasiraj s on 19/9/12.
//  Copyright (c) 2012 appsmerry@gmail.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PeripheralManager.h"
#import "MeBleAppDelegate.h"

@interface MeBleDetailViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,PeripheralManagerDelegate>
{
    NSString *deviceName;
    NSMutableArray *dataArray;
    PeripheralManager *objCurrentDevice;
    NSArray *array;
    NSMutableArray *marry;
    
    MeBleAppDelegate *appDelegate;      //harshIT
    
}

@property(strong,nonatomic)NSArray *array;
@property (weak, nonatomic) IBOutlet UILabel *label;
@property (strong,nonatomic) IBOutlet UILabel *deviceLabel;
/*@property (strong,nonatomic) IBOutlet UILabel *linkloss;
@property (strong,nonatomic) IBOutlet UILabel *RSSI;
@property (strong,nonatomic) IBOutlet UILabel *batterylevel;
@property(strong,nonatomic) IBOutlet UILabel *Txpower;
@property(retain,nonatomic) IBOutlet UITextField *text1;
@property (retain,nonatomic) IBOutlet UITextField *text2;
@property(retain,nonatomic) IBOutlet UITextField *text3;
@property (retain,nonatomic) IBOutlet
UITextField *text4;
@property (strong,nonatomic) IBOutlet UIProgressView *batterybar;*/
@property (nonatomic,retain) NSString *deviceName;
@property(nonatomic,retain) NSMutableArray *dataArray;
@property (weak, nonatomic) IBOutlet UITableView *serviceTable;
@property(strong,nonatomic)PeripheralManager *objCurrentDevice;

@end
