//
//  MeBleFirstViewController.h
//  MoosaTab
//
//  Created by sasiraj s on 19/9/12.
//  Copyright (c) 2012 appsmerry@gmail.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PeripheralManager.h"
#import "MeBleDetailViewController.h"

@interface MeBleFirstViewController : UIViewController
<PeripheralManagerDelegate,UITableViewDataSource,UITableViewDelegate>
{
    NSMutableArray *device;
    NSArray *array;
    UIAlertView *alert;
}

@property (strong, nonatomic) IBOutlet UITableView *deviceTable;
- (IBAction)MeBleUISearch:(id)sender;
@property (strong, nonatomic) IBOutlet UILabel *MeBleUISearch;
@property(retain,nonatomic) NSMutableArray *device;
@property(retain,nonatomic) NSArray *array;
@property(strong,nonatomic) UIAlertView *alert;
@property (weak,nonatomic) UIButton *MeBle;
@property (weak, nonatomic) IBOutlet UIButton *alertButton;
@property (weak, nonatomic) IBOutlet UIButton *batteryButton;

-(void) connectionTimer:(NSTimer *) timer;


@end
