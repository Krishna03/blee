//
//  MeBleDetailViewController.m
//  MoosaTab
//
//  Created by sasiraj s on 19/9/12.
//  Copyright (c) 2012 appsmerry@gmail.com. All rights reserved.
//

#import "MeBleDetailViewController.h"

@interface MeBleDetailViewController ()
{
    //PeripheralManager *peripheralmanager;
}

@end

@implementation MeBleDetailViewController
@synthesize dataArray;
@synthesize deviceName;
@synthesize label;
@synthesize deviceLabel;
@synthesize serviceTable;
@synthesize objCurrentDevice;
@synthesize array;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;

}

- (void)viewDidLoad
{
    [super viewDidLoad];
   NSLog(@"%@",self.dataArray);
    PeripheralManager *peripheralmanager=[[PeripheralManager alloc]init];
   // self.label.text=[NSString stringWithFormat:@" %@ ",dataArray];
	// Do any additional setup after loading the view.
   // [self.dataArray addObject:peripheralmanager.mutableArray];
    
    
    appDelegate = [[UIApplication sharedApplication] delegate]; //harshIT
    
    
    
    // write below line in any function in this file
    NSLog(@"%d",[appDelegate.arrDevices count]);        // HarshIT
    
}

- (void)viewDidUnload
{
    [self setDeviceLabel:nil];
    [self setLabel:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 5;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdentifier=@"Cell1";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    if(cell==nil)
    {
        cell =[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleTableIdentifier];
    }
  cell.textLabel.text=[dataArray objectAtIndex:indexPath.row];
    return cell;
}
@end
