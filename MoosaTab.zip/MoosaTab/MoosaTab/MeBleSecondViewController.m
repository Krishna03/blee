//
//  MeBleSecondViewController.m
//  MoosaTab
//
//  Created by sasiraj s on 19/9/12.
//  Copyright (c) 2012 appsmerry@gmail.com. All rights reserved.
//

#import "MeBleSecondViewController.h"

@interface MeBleSecondViewController ()

@end

@implementation MeBleSecondViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    appDelegate = [[UIApplication sharedApplication] delegate];  // HarshIT
    
    NSLog(@"%d",[appDelegate.arrDevices count]);
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
