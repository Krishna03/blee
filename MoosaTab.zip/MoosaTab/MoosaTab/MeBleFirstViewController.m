//
//  MeBleFirstViewController.m
//  MoosaTab
//
//  Created by sasiraj s on 19/9/12.
//  Copyright (c) 2012 appsmerry@gmail.com. All rights reserved.
//

#import "MeBleFirstViewController.h"

@interface MeBleFirstViewController ()

@end

@implementation MeBleFirstViewController
{
    PeripheralManager *peripheralManager;
}
@synthesize MeBleUISearch;
@synthesize deviceTable;
@synthesize alert;
@synthesize array;
@synthesize MeBle;
@synthesize device;
@synthesize alertButton;
@synthesize batteryButton;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    peripheralManager=[[PeripheralManager alloc]init];
    self.MeBle.enabled=NO;
    device=[[NSMutableArray alloc]init];

}

- (void)viewDidUnload
{
    [self setDeviceTable:nil];
    [self setMeBleUISearch:nil];
    [self setMeBle:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
    
}

#pragma mark - PefipheralManagerDelegate methods

- (void)peripheralManagerDidConnectPeripheral:(PeripheralManager *)peripheral
{
    NSLog(@"%@",peripheral.deviceName);
   [device addObject:[NSString stringWithFormat:@" %@ ",peripheral.deviceName]];    
 //   [device addObject:peripheral];
    [self.deviceTable reloadData];
}

- (void)peripheralManagerDidDisconnectPeripheral:(PeripheralManager *)manager
{
    // self.label.text= @"name";
    self.MeBle.enabled = YES;
    // self.deviceTable.hidden=NO;
    deviceTable.hidden=YES;
}
- (void)peripheralManagerNotifyAlertReady:(PeripheralManager *)manager
{
    self.alertButton.enabled = YES;
}

- (void)peripheralManagerCheckBatteryReady:(PeripheralManager *)manager
{
    self.batteryButton.enabled = YES;
}

- (void)peripheralManager:(PeripheralManager *)manager
          didCheckBattery:(ushort)value
{
    
    alert = [[UIAlertView alloc] initWithTitle:@"batterylevel" 
                                       message:[NSString stringWithFormat:@"Battery power is ー%d%% ", value] 
                                      delegate:nil 
                             cancelButtonTitle:nil 
                             otherButtonTitles:@"OK", nil];
    [alert show];
}

#pragma mark--UI elements

- (IBAction)MeBleUISearch:(id)sender {
    [device removeAllObjects];
    self.MeBle.enabled = YES;
    peripheralManager = [[PeripheralManager alloc] init];
    peripheralManager.delegate = self;
    
    [peripheralManager scanForPeripheralsAndConnect];
    [NSTimer scheduledTimerWithTimeInterval:(float)5.0 target:self selector:@selector(connectionTimer:) userInfo:nil repeats:YES];
    alert=[[UIAlertView alloc] initWithTitle:@"Bluetooth" message:@"Scanning" delegate:nil cancelButtonTitle:@"Cancel" otherButtonTitles:nil];
    UIActivityIndicatorView *progress=[[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(125, 50, 30, 30)];
    [alert addSubview:progress];
    [progress startAnimating];
    [alert show];
    [MeBle setTitle:@"Searching" forState:UIControlStateNormal];
}
- (IBAction)cancelButton:(id)sender {
    
    [peripheralManager stopScaning];
    
    [MeBle setHidden:NO];
    
}
- (void) connectionTimer:(NSTimer *)timer;
{
    [peripheralManager stopScaning];
    [MeBle setTitle:@"Scan For Ble" forState:UIControlStateNormal];
    [alert dismissWithClickedButtonIndex:0 animated:YES];
}


#pragma table view
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return device.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdentifier=@"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    if(cell==nil)
    {
        cell =[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleTableIdentifier];
    }
    cell.textLabel.text=[device objectAtIndex:indexPath.row];
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //MeBleDetailViewController *detail=[self.storyboard instantiateViewControllerWithIdentifier:@"MeBleDetailViewController"];
    // [self.navigationController pushViewController:detail animated:YES];
    
    //[self performSegueWithIdentifier:@"TableDetails" sender:[device objectAtIndex:indexPath.row]];
   // PeripheralManager *objSelectedDevice=[device objectAtIndex:indexPath.row];
}

-(void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    
    
    if ([segue.identifier isEqualToString:@"TableDetails"]) {
        
        MeBleDetailViewController *detail=segue.destinationViewController;
        detail.dataArray=device;
        detail.objCurrentDevice=[device objectAtIndex:[[self.deviceTable indexPathForCell:sender]row]];
        
    }
}
@end
