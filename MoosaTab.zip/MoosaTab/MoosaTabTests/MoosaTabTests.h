//
//  MoosaTabTests.h
//  MoosaTabTests
//
//  Created by sasiraj s on 19/9/12.
//  Copyright (c) 2012 appsmerry@gmail.com. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface MoosaTabTests : SenTestCase

@end
