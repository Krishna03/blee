//
//  PeripheralManager.h
//  MoosaTab
//
//  Created by sasiraj s on 23/10/12.
//  Copyright (c) 2012 appsmerry@gmail.com. All rights reserved.
//

#import <Foundation/Foundation.h>

#import <CoreBluetooth/CoreBluetooth.h>

@class PeripheralManager;

@protocol PeripheralManagerDelegate <NSObject>
@optional

- (void)peripheralManagerDidConnectPeripheral:(PeripheralManager *)manager;

- (void)peripheralManagerDidDisconnectPeripheral:(PeripheralManager *)manager;

- (void)peripheralManagerNotifyAlertReady:(PeripheralManager *)manager;

- (void)peripheralManagerCheckBatteryReady:(PeripheralManager *)manager;

- (void)peripheralManager:(PeripheralManager *)manager
          didCheckBattery:(ushort)value;

@end

@interface PeripheralManager : NSObject <CBCentralManagerDelegate, CBPeripheralDelegate>
{
    NSMutableArray *mutableArray;
}

@property (nonatomic, strong) id<PeripheralManagerDelegate> delegate;
@property (nonatomic, strong) NSString *deviceName;
@property (nonatomic,strong) NSNumber *rssi;
@property (strong,nonatomic) UIButton *connectButton;
@property (strong,nonatomic) NSMutableArray *mutableArray;

- (void)scanForPeripheralsAndConnect;
-(void) stopScaning;
- (void)notifyAlert;
- (void)checkBattery;
-(void) getAllservices:(CBPeripheral *)peripheral;
-(void) getAllCharacteristics:(CBPeripheral *)peripheral;
-(void) ConnectButton:(UIButton *)button;
@end
